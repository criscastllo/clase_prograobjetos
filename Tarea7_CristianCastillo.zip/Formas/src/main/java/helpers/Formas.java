/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

/**
 *
 * @author CristianCastillo
 */
public class Formas {
   String radio;
    String dibujar;
 private int CalcularRadio;


public void establecerRadio (String radio){
this.radio = radio;
}
public String obtenerRadio(){
return this.radio;}

public void establecerDibujar (String dibujar){
this.dibujar = dibujar;
}
public String obtenerDibujar(){
return this.dibujar;}

public void imprimirInfo(){
System.out.println("Radio; " + radio);
System.out.println("Radio; " + dibujar);
}
}
